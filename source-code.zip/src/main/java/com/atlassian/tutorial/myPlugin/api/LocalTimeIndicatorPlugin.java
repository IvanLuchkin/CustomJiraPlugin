package com.atlassian.tutorial.myPlugin.api;

public interface LocalTimeIndicatorPlugin {
    String[] getFormattedLocalTimes();
}